﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RouletteWheel
{
    public partial class roulette : Form
    {
        public roulette()
        {
            InitializeComponent();
        }

        private void pocketBtn_Click(object sender, EventArgs e)
        {
            try
            {
                int tempVal = int.Parse(usrInput.Text);
                if ((tempVal >= 1 && tempVal <= 10) || (tempVal >= 19 && tempVal <= 28))
                {
                    if (tempVal % 2 == 0)
                    {
                        resultLabel.BackColor = Color.Black;
                    } else
                    {
                        resultLabel.BackColor = Color.Red;
                    }
                } else if ((tempVal >= 11 && tempVal <= 18) || (tempVal >= 29 && tempVal <= 36))
                {
                    if (tempVal % 2 == 0)
                    {
                        resultLabel.BackColor = Color.Red;
                    }
                    else
                    {
                        resultLabel.BackColor = Color.Black;
                    }
                } else if (tempVal == 0)
                {
                    resultLabel.BackColor = Color.Green;
                } else
                {
                    MessageBox.Show("Please enter a number 0 - 36");
                }
            } catch
            {
                MessageBox.Show("Please enter a number 0 - 36");
            }
        }
    }
}
