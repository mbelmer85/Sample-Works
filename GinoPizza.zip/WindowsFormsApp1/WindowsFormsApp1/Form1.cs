﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class pizzaApp : Form
    {
        public pizzaApp()
        {
            InitializeComponent();
        }
        // Constant price variables.
        public const decimal THIN_SMALL = 6.0m;
        public const decimal THIN_MED = 8.0m;
        public const decimal THIN_LARGE = 10.0m;
        public const decimal REG_SMALL = 8.0m;
        public const decimal REG_MED = 10.0m;
        public const decimal REG_LARGE = 12.0m;
        public const decimal DEEP_SMALL = 10.0m;
        public const decimal DEEP_MED = 12.0m;
        public const decimal DEEP_LARGE = 14.0m;

        private void totalBtn_Click(object sender, EventArgs e)
        {
            decimal cost = 0m;

            switch (crustList.SelectedIndex) // Switch statement for determining crust type then check size and additional toppings to complete cost.
            {
                case 0:
                    if (smallRadBtn.Checked)
                    {
                        cost = THIN_SMALL;
                        if (onionCheck.Checked)
                        {
                            cost++;
                        }
                        if (pepCheck.Checked)
                        {
                            cost++;
                        }
                        if (avoCheck.Checked)
                        {
                            cost++;
                        }
                        if (sausCheck.Checked)
                        {
                            cost++;
                        }
                        if (hamburgCheck.Checked)
                        {
                            cost++;
                        }
                        if (chickenCheck.Checked)
                        {
                            cost++;
                        }
                        if (cheeseCheck.Checked)
                        {
                            cost++;
                        }
                    } else if (mediumRadBtn.Checked)
                    {
                        cost = THIN_MED;
                        if (onionCheck.Checked)
                        {
                            cost++;
                        }
                        if (pepCheck.Checked)
                        {
                            cost++;
                        }
                        if (avoCheck.Checked)
                        {
                            cost++;
                        }
                        if (sausCheck.Checked)
                        {
                            cost++;
                        }
                        if (hamburgCheck.Checked)
                        {
                            cost++;
                        }
                        if (chickenCheck.Checked)
                        {
                            cost++;
                        }
                        if (cheeseCheck.Checked)
                        {
                            cost++;
                        }
                    } else if (largeRadBtn.Checked)
                    {
                        cost = THIN_LARGE;
                        if (onionCheck.Checked)
                        {
                            cost++;
                        }
                        if (pepCheck.Checked)
                        {
                            cost++;
                        }
                        if (avoCheck.Checked)
                        {
                            cost++;
                        }
                        if (sausCheck.Checked)
                        {
                            cost++;
                        }
                        if (hamburgCheck.Checked)
                        {
                            cost++;
                        }
                        if (chickenCheck.Checked)
                        {
                            cost++;
                        }
                        if (cheeseCheck.Checked)
                        {
                            cost++;
                        }
                    }
                    break;
                case 1:
                    if (smallRadBtn.Checked)
                    {
                        cost = REG_SMALL;
                        if (onionCheck.Checked)
                        {
                            cost++;
                        }
                        if (pepCheck.Checked)
                        {
                            cost++;
                        }
                        if (avoCheck.Checked)
                        {
                            cost++;
                        }
                        if (sausCheck.Checked)
                        {
                            cost++;
                        }
                        if (hamburgCheck.Checked)
                        {
                            cost++;
                        }
                        if (chickenCheck.Checked)
                        {
                            cost++;
                        }
                        if (cheeseCheck.Checked)
                        {
                            cost++;
                        }
                    } else if (mediumRadBtn.Checked)
                    {
                        cost = REG_MED;
                        if (onionCheck.Checked)
                        {
                            cost++;
                        }
                        if (pepCheck.Checked)
                        {
                            cost++;
                        }
                        if (avoCheck.Checked)
                        {
                            cost++;
                        }
                        if (sausCheck.Checked)
                        {
                            cost++;
                        }
                        if (hamburgCheck.Checked)
                        {
                            cost++;
                        }
                        if (chickenCheck.Checked)
                        {
                            cost++;
                        }
                        if (cheeseCheck.Checked)
                        {
                            cost++;
                        }
                    } else if (largeRadBtn.Checked)
                    {
                        cost = REG_LARGE;
                        if (onionCheck.Checked)
                        {
                            cost++;
                        }
                        if (pepCheck.Checked)
                        {
                            cost++;
                        }
                        if (avoCheck.Checked)
                        {
                            cost++;
                        }
                        if (sausCheck.Checked)
                        {
                            cost++;
                        }
                        if (hamburgCheck.Checked)
                        {
                            cost++;
                        }
                        if (chickenCheck.Checked)
                        {
                            cost++;
                        }
                        if (cheeseCheck.Checked)
                        {
                            cost++;
                        }
                    }
                    break;
                case 2:
                    if (smallRadBtn.Checked)
                    {
                        cost = DEEP_SMALL;
                        if (onionCheck.Checked)
                        {
                            cost++;
                        }
                        if (pepCheck.Checked)
                        {
                            cost++;
                        }
                        if (avoCheck.Checked)
                        {
                            cost++;
                        }
                        if (sausCheck.Checked)
                        {
                            cost++;
                        }
                        if (hamburgCheck.Checked)
                        {
                            cost++;
                        }
                        if (chickenCheck.Checked)
                        {
                            cost++;
                        }
                        if (cheeseCheck.Checked)
                        {
                            cost++;
                        }
                    } else if (mediumRadBtn.Checked)
                    {
                        cost = DEEP_MED;
                        if (onionCheck.Checked)
                        {
                            cost++;
                        }
                        if (pepCheck.Checked)
                        {
                            cost++;
                        }
                        if (avoCheck.Checked)
                        {
                            cost++;
                        }
                        if (sausCheck.Checked)
                        {
                            cost++;
                        }
                        if (hamburgCheck.Checked)
                        {
                            cost++;
                        }
                        if (chickenCheck.Checked)
                        {
                            cost++;
                        }
                        if (cheeseCheck.Checked)
                        {
                            cost++;
                        }
                    } else if (largeRadBtn.Checked)
                    {
                        cost = DEEP_LARGE;
                        if (onionCheck.Checked)
                        {
                            cost++;
                        }
                        if (pepCheck.Checked)
                        {
                            cost++;
                        }
                        if (avoCheck.Checked)
                        {
                            cost++;
                        }
                        if (sausCheck.Checked)
                        {
                            cost++;
                        }
                        if (hamburgCheck.Checked)
                        {
                            cost++;
                        }
                        if (chickenCheck.Checked)
                        {
                            cost++;
                        }
                        if (cheeseCheck.Checked)
                        {
                            cost++;
                        }
                    }
                    break;
            }

            resultLabel.Text = cost.ToString("C"); // Display cost to user.
        }
    }
}
