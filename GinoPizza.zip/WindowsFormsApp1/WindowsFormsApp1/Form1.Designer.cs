﻿namespace WindowsFormsApp1
{
    partial class pizzaApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sizeGrpBx = new System.Windows.Forms.GroupBox();
            this.largeRadBtn = new System.Windows.Forms.RadioButton();
            this.mediumRadBtn = new System.Windows.Forms.RadioButton();
            this.smallRadBtn = new System.Windows.Forms.RadioButton();
            this.toppingsGrpBx = new System.Windows.Forms.GroupBox();
            this.cheeseCheck = new System.Windows.Forms.CheckBox();
            this.chickenCheck = new System.Windows.Forms.CheckBox();
            this.hamburgCheck = new System.Windows.Forms.CheckBox();
            this.sausCheck = new System.Windows.Forms.CheckBox();
            this.avoCheck = new System.Windows.Forms.CheckBox();
            this.pepCheck = new System.Windows.Forms.CheckBox();
            this.onionCheck = new System.Windows.Forms.CheckBox();
            this.crustList = new System.Windows.Forms.ListBox();
            this.totalBtn = new System.Windows.Forms.Button();
            this.resultLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.sizeGrpBx.SuspendLayout();
            this.toppingsGrpBx.SuspendLayout();
            this.SuspendLayout();
            // 
            // sizeGrpBx
            // 
            this.sizeGrpBx.BackColor = System.Drawing.Color.IndianRed;
            this.sizeGrpBx.Controls.Add(this.largeRadBtn);
            this.sizeGrpBx.Controls.Add(this.mediumRadBtn);
            this.sizeGrpBx.Controls.Add(this.smallRadBtn);
            this.sizeGrpBx.Location = new System.Drawing.Point(18, 15);
            this.sizeGrpBx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sizeGrpBx.Name = "sizeGrpBx";
            this.sizeGrpBx.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sizeGrpBx.Size = new System.Drawing.Size(198, 223);
            this.sizeGrpBx.TabIndex = 0;
            this.sizeGrpBx.TabStop = false;
            this.sizeGrpBx.Text = "SIZE";
            // 
            // largeRadBtn
            // 
            this.largeRadBtn.AutoSize = true;
            this.largeRadBtn.Location = new System.Drawing.Point(56, 142);
            this.largeRadBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.largeRadBtn.Name = "largeRadBtn";
            this.largeRadBtn.Size = new System.Drawing.Size(76, 20);
            this.largeRadBtn.TabIndex = 2;
            this.largeRadBtn.TabStop = true;
            this.largeRadBtn.Text = "LARGE";
            this.largeRadBtn.UseVisualStyleBackColor = true;
            // 
            // mediumRadBtn
            // 
            this.mediumRadBtn.AutoSize = true;
            this.mediumRadBtn.Location = new System.Drawing.Point(56, 90);
            this.mediumRadBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mediumRadBtn.Name = "mediumRadBtn";
            this.mediumRadBtn.Size = new System.Drawing.Size(86, 20);
            this.mediumRadBtn.TabIndex = 1;
            this.mediumRadBtn.TabStop = true;
            this.mediumRadBtn.Text = "MEDIUM";
            this.mediumRadBtn.UseVisualStyleBackColor = true;
            // 
            // smallRadBtn
            // 
            this.smallRadBtn.AutoSize = true;
            this.smallRadBtn.Checked = true;
            this.smallRadBtn.Location = new System.Drawing.Point(56, 47);
            this.smallRadBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.smallRadBtn.Name = "smallRadBtn";
            this.smallRadBtn.Size = new System.Drawing.Size(74, 20);
            this.smallRadBtn.TabIndex = 0;
            this.smallRadBtn.TabStop = true;
            this.smallRadBtn.Text = "SMALL";
            this.smallRadBtn.UseVisualStyleBackColor = true;
            // 
            // toppingsGrpBx
            // 
            this.toppingsGrpBx.BackColor = System.Drawing.Color.IndianRed;
            this.toppingsGrpBx.Controls.Add(this.cheeseCheck);
            this.toppingsGrpBx.Controls.Add(this.chickenCheck);
            this.toppingsGrpBx.Controls.Add(this.hamburgCheck);
            this.toppingsGrpBx.Controls.Add(this.sausCheck);
            this.toppingsGrpBx.Controls.Add(this.avoCheck);
            this.toppingsGrpBx.Controls.Add(this.pepCheck);
            this.toppingsGrpBx.Controls.Add(this.onionCheck);
            this.toppingsGrpBx.Location = new System.Drawing.Point(224, 15);
            this.toppingsGrpBx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.toppingsGrpBx.Name = "toppingsGrpBx";
            this.toppingsGrpBx.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.toppingsGrpBx.Size = new System.Drawing.Size(202, 347);
            this.toppingsGrpBx.TabIndex = 1;
            this.toppingsGrpBx.TabStop = false;
            this.toppingsGrpBx.Text = "Additional Items";
            // 
            // cheeseCheck
            // 
            this.cheeseCheck.AutoSize = true;
            this.cheeseCheck.Location = new System.Drawing.Point(45, 298);
            this.cheeseCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cheeseCheck.Name = "cheeseCheck";
            this.cheeseCheck.Size = new System.Drawing.Size(119, 20);
            this.cheeseCheck.TabIndex = 6;
            this.cheeseCheck.Text = "Extra Cheese";
            this.cheeseCheck.UseVisualStyleBackColor = true;
            // 
            // chickenCheck
            // 
            this.chickenCheck.AutoSize = true;
            this.chickenCheck.Location = new System.Drawing.Point(45, 256);
            this.chickenCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chickenCheck.Name = "chickenCheck";
            this.chickenCheck.Size = new System.Drawing.Size(82, 20);
            this.chickenCheck.TabIndex = 5;
            this.chickenCheck.Text = "Chicken";
            this.chickenCheck.UseVisualStyleBackColor = true;
            // 
            // hamburgCheck
            // 
            this.hamburgCheck.AutoSize = true;
            this.hamburgCheck.Location = new System.Drawing.Point(45, 214);
            this.hamburgCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.hamburgCheck.Name = "hamburgCheck";
            this.hamburgCheck.Size = new System.Drawing.Size(104, 20);
            this.hamburgCheck.TabIndex = 4;
            this.hamburgCheck.Text = "Hamburger";
            this.hamburgCheck.UseVisualStyleBackColor = true;
            // 
            // sausCheck
            // 
            this.sausCheck.AutoSize = true;
            this.sausCheck.Location = new System.Drawing.Point(45, 171);
            this.sausCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sausCheck.Name = "sausCheck";
            this.sausCheck.Size = new System.Drawing.Size(89, 20);
            this.sausCheck.TabIndex = 3;
            this.sausCheck.Text = "Sausage";
            this.sausCheck.UseVisualStyleBackColor = true;
            // 
            // avoCheck
            // 
            this.avoCheck.AutoSize = true;
            this.avoCheck.Location = new System.Drawing.Point(45, 130);
            this.avoCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.avoCheck.Name = "avoCheck";
            this.avoCheck.Size = new System.Drawing.Size(89, 20);
            this.avoCheck.TabIndex = 2;
            this.avoCheck.Text = "Avocado";
            this.avoCheck.UseVisualStyleBackColor = true;
            // 
            // pepCheck
            // 
            this.pepCheck.AutoSize = true;
            this.pepCheck.Location = new System.Drawing.Point(45, 90);
            this.pepCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pepCheck.Name = "pepCheck";
            this.pepCheck.Size = new System.Drawing.Size(78, 20);
            this.pepCheck.TabIndex = 1;
            this.pepCheck.Text = "Pepper";
            this.pepCheck.UseVisualStyleBackColor = true;
            // 
            // onionCheck
            // 
            this.onionCheck.AutoSize = true;
            this.onionCheck.Location = new System.Drawing.Point(45, 47);
            this.onionCheck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.onionCheck.Name = "onionCheck";
            this.onionCheck.Size = new System.Drawing.Size(67, 20);
            this.onionCheck.TabIndex = 0;
            this.onionCheck.Text = "Onion";
            this.onionCheck.UseVisualStyleBackColor = true;
            // 
            // crustList
            // 
            this.crustList.BackColor = System.Drawing.Color.IndianRed;
            this.crustList.FormattingEnabled = true;
            this.crustList.ItemHeight = 16;
            this.crustList.Items.AddRange(new object[] {
            "Thin Crust",
            "Regular Crust",
            "Deep Dish Crust"});
            this.crustList.Location = new System.Drawing.Point(18, 310);
            this.crustList.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.crustList.Name = "crustList";
            this.crustList.Size = new System.Drawing.Size(198, 52);
            this.crustList.TabIndex = 2;
            // 
            // totalBtn
            // 
            this.totalBtn.BackColor = System.Drawing.Color.AntiqueWhite;
            this.totalBtn.Location = new System.Drawing.Point(33, 402);
            this.totalBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.totalBtn.Name = "totalBtn";
            this.totalBtn.Size = new System.Drawing.Size(183, 67);
            this.totalBtn.TabIndex = 3;
            this.totalBtn.Text = "Get Total";
            this.totalBtn.UseVisualStyleBackColor = false;
            this.totalBtn.Click += new System.EventHandler(this.totalBtn_Click);
            // 
            // resultLabel
            // 
            this.resultLabel.BackColor = System.Drawing.Color.AntiqueWhite;
            this.resultLabel.Location = new System.Drawing.Point(245, 402);
            this.resultLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(167, 76);
            this.resultLabel.TabIndex = 4;
            this.resultLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(245, 386);
            this.totalLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(86, 16);
            this.totalLabel.TabIndex = 5;
            this.totalLabel.Text = "Final Total:";
            // 
            // pizzaApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(463, 510);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.totalBtn);
            this.Controls.Add(this.crustList);
            this.Controls.Add(this.toppingsGrpBx);
            this.Controls.Add(this.sizeGrpBx);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "pizzaApp";
            this.Text = "Gino\'s Pizza";
            this.sizeGrpBx.ResumeLayout(false);
            this.sizeGrpBx.PerformLayout();
            this.toppingsGrpBx.ResumeLayout(false);
            this.toppingsGrpBx.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox sizeGrpBx;
        private System.Windows.Forms.RadioButton largeRadBtn;
        private System.Windows.Forms.RadioButton mediumRadBtn;
        private System.Windows.Forms.RadioButton smallRadBtn;
        private System.Windows.Forms.GroupBox toppingsGrpBx;
        private System.Windows.Forms.CheckBox cheeseCheck;
        private System.Windows.Forms.CheckBox chickenCheck;
        private System.Windows.Forms.CheckBox hamburgCheck;
        private System.Windows.Forms.CheckBox sausCheck;
        private System.Windows.Forms.CheckBox avoCheck;
        private System.Windows.Forms.CheckBox pepCheck;
        private System.Windows.Forms.CheckBox onionCheck;
        private System.Windows.Forms.ListBox crustList;
        private System.Windows.Forms.Button totalBtn;
        private System.Windows.Forms.Label resultLabel;
        private System.Windows.Forms.Label totalLabel;
    }
}

