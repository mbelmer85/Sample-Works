﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace divByNine___Loops
{
    public partial class divByNine : Form
    {
        public divByNine()
        {
            InitializeComponent();
        }

        private void forBtn_Click(object sender, EventArgs e)
        {
            try
            {
                int inputLength = userInput.Text.Length; // Store user input's length
                int inputNum = int.Parse(userInput.Text); // Store user input's number if possible
                if (inputNum >= 0) // check for positive integer
                {
                    int count = 0; // Storage for added integers from user input
                    for (int i = 0; i <= inputLength; i++) // use for loop to add integers
                    {
                        count = count + inputNum % 10;
                        inputNum = inputNum / 10;
                    } //end for
                    if (count % 9 != 0) // check for divisibility
                    {
                        MessageBox.Show("Input not divisible by 9");
                        userInput.Text = "";
                    } //end if
                    else
                    {
                        resultListBox.Items.Add(userInput.Text); // add number to listbox of divisible numbers
                    } //end else
                } //end if
                else
                {
                    MessageBox.Show("Please enter a positive integer"); // error for non positive integers
                    userInput.Text = "";
                } //end else
            } //end try
            catch
            {
                MessageBox.Show("Please enter a positive integer"); // error if int.Parse doesn't find an int value
                userInput.Text = "";
            } //end catch
        } //end forBtn_Click()

        private void whileBtn_Click(object sender, EventArgs e)
        {
            try
            {
                int inputLength = userInput.Text.Length; // Store user input's length
                int inputNum = int.Parse(userInput.Text); // Store user input's number if possible
                if (inputNum >= 0) // check for positive integer
                {
                    int count = 0; // Storage for added integers from user input
                    int i = 0;
                    while (i <= inputLength)
                    {
                        count = count + inputNum % 10;
                        inputNum = inputNum / 10;
                        i++;
                    } //end while
                    if (count % 9 != 0) // check for divisibility
                    {
                        MessageBox.Show("Input not divisible by 9");
                        userInput.Text = "";
                    } //end if
                    else
                    {
                        resultListBox.Items.Add(userInput.Text); // add number to listbox of divisible numbers
                    } //end else
                } //end if
                else
                {
                    MessageBox.Show("Please enter a positive integer"); // error for non positive integers
                    userInput.Text = "";
                } //end else
            } //end try
            catch
            {
                MessageBox.Show("Please enter a positive integer"); // error if int.Parse doesn't find an int value
                userInput.Text = "";
            } //end catch
        } //end whileBtn_Click()

        private void clearBtn_Click(object sender, EventArgs e)
        {
            resultListBox.Items.Clear();
        } //end clearBtn_Click()
    } //end divByNine
} //end divByNine___Loops
