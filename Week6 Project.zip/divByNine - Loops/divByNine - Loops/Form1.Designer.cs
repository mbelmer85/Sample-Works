﻿namespace divByNine___Loops
{
    partial class divByNine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userInput = new System.Windows.Forms.TextBox();
            this.resultListBox = new System.Windows.Forms.ListBox();
            this.forBtn = new System.Windows.Forms.Button();
            this.whileBtn = new System.Windows.Forms.Button();
            this.textBoxLabel = new System.Windows.Forms.Label();
            this.resultLabel = new System.Windows.Forms.Label();
            this.clearBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // userInput
            // 
            this.userInput.BackColor = System.Drawing.Color.LightCyan;
            this.userInput.Location = new System.Drawing.Point(13, 29);
            this.userInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.userInput.Name = "userInput";
            this.userInput.Size = new System.Drawing.Size(148, 22);
            this.userInput.TabIndex = 0;
            // 
            // resultListBox
            // 
            this.resultListBox.BackColor = System.Drawing.Color.LightCyan;
            this.resultListBox.FormattingEnabled = true;
            this.resultListBox.ItemHeight = 16;
            this.resultListBox.Location = new System.Drawing.Point(248, 29);
            this.resultListBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.resultListBox.Name = "resultListBox";
            this.resultListBox.Size = new System.Drawing.Size(178, 116);
            this.resultListBox.TabIndex = 1;
            // 
            // forBtn
            // 
            this.forBtn.BackColor = System.Drawing.Color.MediumTurquoise;
            this.forBtn.Location = new System.Drawing.Point(13, 59);
            this.forBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.forBtn.Name = "forBtn";
            this.forBtn.Size = new System.Drawing.Size(136, 60);
            this.forBtn.TabIndex = 2;
            this.forBtn.Text = "FOR";
            this.forBtn.UseVisualStyleBackColor = false;
            this.forBtn.Click += new System.EventHandler(this.forBtn_Click);
            // 
            // whileBtn
            // 
            this.whileBtn.BackColor = System.Drawing.Color.MediumTurquoise;
            this.whileBtn.Location = new System.Drawing.Point(13, 134);
            this.whileBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.whileBtn.Name = "whileBtn";
            this.whileBtn.Size = new System.Drawing.Size(136, 62);
            this.whileBtn.TabIndex = 3;
            this.whileBtn.Text = "WHILE";
            this.whileBtn.UseVisualStyleBackColor = false;
            this.whileBtn.Click += new System.EventHandler(this.whileBtn_Click);
            // 
            // textBoxLabel
            // 
            this.textBoxLabel.AutoSize = true;
            this.textBoxLabel.Location = new System.Drawing.Point(13, 9);
            this.textBoxLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textBoxLabel.Name = "textBoxLabel";
            this.textBoxLabel.Size = new System.Drawing.Size(172, 16);
            this.textBoxLabel.TabIndex = 4;
            this.textBoxLabel.Text = "Enter a positive integer:";
            // 
            // resultLabel
            // 
            this.resultLabel.AutoSize = true;
            this.resultLabel.Location = new System.Drawing.Point(201, 9);
            this.resultLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(225, 16);
            this.resultLabel.TabIndex = 5;
            this.resultLabel.Text = "Entered numbers divisible by 9:";
            // 
            // clearBtn
            // 
            this.clearBtn.BackColor = System.Drawing.Color.MediumTurquoise;
            this.clearBtn.Location = new System.Drawing.Point(311, 152);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(115, 44);
            this.clearBtn.TabIndex = 6;
            this.clearBtn.Text = "CLEAR";
            this.clearBtn.UseVisualStyleBackColor = false;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // divByNine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(447, 216);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.textBoxLabel);
            this.Controls.Add(this.whileBtn);
            this.Controls.Add(this.forBtn);
            this.Controls.Add(this.resultListBox);
            this.Controls.Add(this.userInput);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "divByNine";
            this.Text = "Loops Demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox userInput;
        private System.Windows.Forms.ListBox resultListBox;
        private System.Windows.Forms.Button forBtn;
        private System.Windows.Forms.Button whileBtn;
        private System.Windows.Forms.Label textBoxLabel;
        private System.Windows.Forms.Label resultLabel;
        private System.Windows.Forms.Button clearBtn;
    }
}

