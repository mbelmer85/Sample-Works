﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleSubs
{
    public partial class simpleSubs : Form
    {
        public simpleSubs()
        {
            InitializeComponent();
        }

        private void calcBtn_Click(object sender, EventArgs e)
        {
            try
            {
                decimal avo = decimal.Parse(avoInput.Text);
                decimal meat = decimal.Parse(meatInput.Text);
                decimal veg = decimal.Parse(vegInput.Text);
                decimal pep = decimal.Parse(pepInput.Text);
                decimal price = 5.0m; // Instructions gave no base price so I set to 5 dollars.
                if (avo < 0 || avo > 5 || meat < 0 || meat > 5 || veg < 0 || veg > 5 || pep < 0 || pep > 5) // check for valid values.
                {
                    MessageBox.Show("Please enter a value between 0-5."); // display message for invalid inputs and reset inputs.
                    avoInput.Text = "0";
                    meatInput.Text = "0";
                    vegInput.Text = "0";
                    pepInput.Text = "0";
                    wheatInput.Text = "No";
                    seedInput.Text = "No";
                    priceLabel.Text = "0.0";
                }
                if ((String.Compare(wheatInput.Text, "Yes", true) == 0 || String.Compare(wheatInput.Text, "No", true) == 0) && (String.Compare(seedInput.Text, "Yes", true) == 0 || String.Compare(seedInput.Text, "No", true) == 0)) // check for valid values.
                {
                    if (String.Compare(wheatInput.Text, "Yes", true) == 0)
                    {
                        price += 1.0m;
                    }
                    if (String.Compare(seedInput.Text, "Yes", true) == 0)
                    {
                        price += 0.5m;
                    }
                } else
                {
                    MessageBox.Show("Please enter Yes or No for bread types."); // display message for invalid inputs and reset inputs.
                    avoInput.Text = "0";
                    meatInput.Text = "0";
                    vegInput.Text = "0";
                    pepInput.Text = "0";
                    priceLabel.Text = "0.0"; // for some reason this line is not being run. It does in all other instances. ???
                    wheatInput.Text = "No";
                    seedInput.Text = "No";
                }
                price += (avo * 0.75m) + (meat * 2.0m) + (pep * 0.5m) + (veg * 1.0m); // calculate sub price.
                priceLabel.Text = price.ToString(); // display final price in result label.
            } catch
            {
                MessageBox.Show("Please use valid inputs."); // display message for invalid inputs and reset inputs.
                avoInput.Text = "0";
                meatInput.Text = "0";
                vegInput.Text = "0";
                pepInput.Text = "0";
                wheatInput.Text = "No";
                seedInput.Text = "No";
                priceLabel.Text = "0.0";
            }
        }
    }
}
