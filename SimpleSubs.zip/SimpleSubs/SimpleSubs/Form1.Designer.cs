﻿namespace SimpleSubs
{
    partial class simpleSubs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.avoInput = new System.Windows.Forms.TextBox();
            this.meatInput = new System.Windows.Forms.TextBox();
            this.vegInput = new System.Windows.Forms.TextBox();
            this.pepInput = new System.Windows.Forms.TextBox();
            this.wheatInput = new System.Windows.Forms.TextBox();
            this.seedInput = new System.Windows.Forms.TextBox();
            this.calcBtn = new System.Windows.Forms.Button();
            this.avoLabel = new System.Windows.Forms.Label();
            this.meatLabel = new System.Windows.Forms.Label();
            this.vegLabel = new System.Windows.Forms.Label();
            this.pepLabel = new System.Windows.Forms.Label();
            this.wheatLabel = new System.Windows.Forms.Label();
            this.seedLabel = new System.Windows.Forms.Label();
            this.priceLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // avoInput
            // 
            this.avoInput.Location = new System.Drawing.Point(267, 163);
            this.avoInput.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.avoInput.Name = "avoInput";
            this.avoInput.Size = new System.Drawing.Size(164, 26);
            this.avoInput.TabIndex = 0;
            this.avoInput.Text = "0";
            // 
            // meatInput
            // 
            this.meatInput.Location = new System.Drawing.Point(267, 289);
            this.meatInput.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.meatInput.Name = "meatInput";
            this.meatInput.Size = new System.Drawing.Size(164, 26);
            this.meatInput.TabIndex = 1;
            this.meatInput.Text = "0";
            // 
            // vegInput
            // 
            this.vegInput.Location = new System.Drawing.Point(267, 407);
            this.vegInput.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.vegInput.Name = "vegInput";
            this.vegInput.Size = new System.Drawing.Size(164, 26);
            this.vegInput.TabIndex = 2;
            this.vegInput.Text = "0";
            // 
            // pepInput
            // 
            this.pepInput.Location = new System.Drawing.Point(267, 526);
            this.pepInput.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.pepInput.Name = "pepInput";
            this.pepInput.Size = new System.Drawing.Size(164, 26);
            this.pepInput.TabIndex = 3;
            this.pepInput.Text = "0";
            // 
            // wheatInput
            // 
            this.wheatInput.Location = new System.Drawing.Point(713, 283);
            this.wheatInput.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.wheatInput.Name = "wheatInput";
            this.wheatInput.Size = new System.Drawing.Size(164, 26);
            this.wheatInput.TabIndex = 4;
            this.wheatInput.Text = "No";
            // 
            // seedInput
            // 
            this.seedInput.Location = new System.Drawing.Point(713, 401);
            this.seedInput.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.seedInput.Name = "seedInput";
            this.seedInput.Size = new System.Drawing.Size(164, 26);
            this.seedInput.TabIndex = 5;
            this.seedInput.Text = "No";
            // 
            // calcBtn
            // 
            this.calcBtn.Location = new System.Drawing.Point(51, 623);
            this.calcBtn.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.calcBtn.Name = "calcBtn";
            this.calcBtn.Size = new System.Drawing.Size(445, 158);
            this.calcBtn.TabIndex = 6;
            this.calcBtn.Text = "Calculate Price";
            this.calcBtn.UseVisualStyleBackColor = true;
            this.calcBtn.Click += new System.EventHandler(this.calcBtn_Click);
            // 
            // avoLabel
            // 
            this.avoLabel.BackColor = System.Drawing.Color.LightSalmon;
            this.avoLabel.Location = new System.Drawing.Point(42, 132);
            this.avoLabel.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.avoLabel.Name = "avoLabel";
            this.avoLabel.Size = new System.Drawing.Size(190, 82);
            this.avoLabel.TabIndex = 7;
            this.avoLabel.Text = "Avocado";
            // 
            // meatLabel
            // 
            this.meatLabel.BackColor = System.Drawing.Color.LightSalmon;
            this.meatLabel.Location = new System.Drawing.Point(47, 266);
            this.meatLabel.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.meatLabel.Name = "meatLabel";
            this.meatLabel.Size = new System.Drawing.Size(185, 88);
            this.meatLabel.TabIndex = 8;
            this.meatLabel.Text = "Meat";
            // 
            // vegLabel
            // 
            this.vegLabel.BackColor = System.Drawing.Color.LightSalmon;
            this.vegLabel.Location = new System.Drawing.Point(47, 392);
            this.vegLabel.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.vegLabel.Name = "vegLabel";
            this.vegLabel.Size = new System.Drawing.Size(185, 78);
            this.vegLabel.TabIndex = 9;
            this.vegLabel.Text = "Veggies";
            // 
            // pepLabel
            // 
            this.pepLabel.BackColor = System.Drawing.Color.LightSalmon;
            this.pepLabel.Location = new System.Drawing.Point(47, 505);
            this.pepLabel.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.pepLabel.Name = "pepLabel";
            this.pepLabel.Size = new System.Drawing.Size(185, 79);
            this.pepLabel.TabIndex = 10;
            this.pepLabel.Text = "Pepperocini";
            // 
            // wheatLabel
            // 
            this.wheatLabel.AutoSize = true;
            this.wheatLabel.Location = new System.Drawing.Point(561, 289);
            this.wheatLabel.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.wheatLabel.Name = "wheatLabel";
            this.wheatLabel.Size = new System.Drawing.Size(116, 20);
            this.wheatLabel.TabIndex = 11;
            this.wheatLabel.Text = "Whole Wheat";
            // 
            // seedLabel
            // 
            this.seedLabel.AutoSize = true;
            this.seedLabel.Location = new System.Drawing.Point(561, 407);
            this.seedLabel.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.seedLabel.Name = "seedLabel";
            this.seedLabel.Size = new System.Drawing.Size(124, 20);
            this.seedLabel.TabIndex = 12;
            this.seedLabel.Text = "Seeded Bread";
            // 
            // priceLabel
            // 
            this.priceLabel.BackColor = System.Drawing.Color.LightSalmon;
            this.priceLabel.Location = new System.Drawing.Point(626, 623);
            this.priceLabel.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.priceLabel.Name = "priceLabel";
            this.priceLabel.Size = new System.Drawing.Size(329, 158);
            this.priceLabel.TabIndex = 13;
            this.priceLabel.Text = "0.0";
            this.priceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // simpleSubs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(1088, 814);
            this.Controls.Add(this.priceLabel);
            this.Controls.Add(this.seedLabel);
            this.Controls.Add(this.wheatLabel);
            this.Controls.Add(this.pepLabel);
            this.Controls.Add(this.vegLabel);
            this.Controls.Add(this.meatLabel);
            this.Controls.Add(this.avoLabel);
            this.Controls.Add(this.calcBtn);
            this.Controls.Add(this.seedInput);
            this.Controls.Add(this.wheatInput);
            this.Controls.Add(this.pepInput);
            this.Controls.Add(this.vegInput);
            this.Controls.Add(this.meatInput);
            this.Controls.Add(this.avoInput);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Name = "simpleSubs";
            this.Text = "Simple Subs";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox avoInput;
        private System.Windows.Forms.TextBox meatInput;
        private System.Windows.Forms.TextBox vegInput;
        private System.Windows.Forms.TextBox pepInput;
        private System.Windows.Forms.TextBox wheatInput;
        private System.Windows.Forms.TextBox seedInput;
        private System.Windows.Forms.Button calcBtn;
        private System.Windows.Forms.Label avoLabel;
        private System.Windows.Forms.Label meatLabel;
        private System.Windows.Forms.Label vegLabel;
        private System.Windows.Forms.Label pepLabel;
        private System.Windows.Forms.Label wheatLabel;
        private System.Windows.Forms.Label seedLabel;
        private System.Windows.Forms.Label priceLabel;
    }
}

