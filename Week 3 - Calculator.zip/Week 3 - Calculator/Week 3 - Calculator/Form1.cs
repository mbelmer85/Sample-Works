﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_3___Calculator
{
    public partial class Calculator : Form
    {
        private static string OPERAND_ERROR = "Please enter a valid operand.";
        public Calculator()
        {
            InitializeComponent();
        }

        private void dig1op1_Click(object sender, EventArgs e)
        {
            op1Input.Text += "1";
        }

        private void dig2op1_Click(object sender, EventArgs e)
        {
            op1Input.Text += "2";
        }

        private void dig3op1_Click(object sender, EventArgs e)
        {
            op1Input.Text += "3";
        }

        private void dig4op1_Click(object sender, EventArgs e)
        {
            op1Input.Text += "4";
        }

        private void dig5op1_Click(object sender, EventArgs e)
        {
            op1Input.Text += "5";
        }

        private void dig6op1_Click(object sender, EventArgs e)
        {
            op1Input.Text += "6";
        }

        private void dig7op1_Click(object sender, EventArgs e)
        {
            op1Input.Text += "7";
        }

        private void dig8op1_Click(object sender, EventArgs e)
        {
            op1Input.Text += "8";
        }

        private void dig9op1_Click(object sender, EventArgs e)
        {
            op1Input.Text += "9";
        }

        private void dig0op1_Click(object sender, EventArgs e)
        {
            op1Input.Text += "0";
        }

        private void backspaceOp1_Click(object sender, EventArgs e)
        {
            try
            {
                int tempVal = int.Parse(op1Input.Text) / 10; //Store value of current user input minus last digit.
                if (tempVal == 0) // check for last digit to delete
                {
                    op1Input.Text = "";
                }
                else
                {
                    op1Input.Text = tempVal.ToString();
                }
            } catch
            {
                MessageBox.Show(OPERAND_ERROR);
            }
        }

        private void dig1op2_Click(object sender, EventArgs e)
        {
            op2Input.Text += "1";
        }

        private void dig2op2_Click(object sender, EventArgs e)
        {
            op2Input.Text += "2";
        }

        private void dig3op2_Click(object sender, EventArgs e)
        {
            op2Input.Text += "3";
        }

        private void dig4op2_Click(object sender, EventArgs e)
        {
            op2Input.Text += "4";
        }

        private void dig5op2_Click(object sender, EventArgs e)
        {
            op2Input.Text += "5";
        }

        private void dig6op2_Click(object sender, EventArgs e)
        {
            op2Input.Text += "6";
        }

        private void dig7op2_Click(object sender, EventArgs e)
        {
            op2Input.Text += "7";
        }

        private void dig8op2_Click(object sender, EventArgs e)
        {
            op2Input.Text += "8";
        }

        private void dig9op2_Click(object sender, EventArgs e)
        {
            op2Input.Text += "9";
        }

        private void dig0op2_Click(object sender, EventArgs e)
        {
            op2Input.Text += "0";
        }

        private void backspaceOp2_Click(object sender, EventArgs e)
        {
            try
            {
                int tempVal = int.Parse(op2Input.Text) / 10; //Store value of current user input minus last digit.
                if (tempVal == 0) // check for last digit to delete
                {
                    op2Input.Text = "";
                }
                else
                {
                    op2Input.Text = tempVal.ToString();
                }
            }
            catch
            {
                MessageBox.Show(OPERAND_ERROR);
            }
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            try
            {
                double op1 = double.Parse(op1Input.Text); //Store operand 1
                double op2 = double.Parse(op2Input.Text); //Store operand 2
                double result = op1 + op2; //Compute calculation
                outputLabel.Text = result.ToString(); //Display results
            } catch
            {
                MessageBox.Show(OPERAND_ERROR);
            }
        }

        private void subBtn_Click(object sender, EventArgs e)
        {
            try
            {
                double op1 = double.Parse(op1Input.Text); //Store operand 1
                double op2 = double.Parse(op2Input.Text); //Store operand 2
                double result = op1 - op2; //Compute calculation
                outputLabel.Text = result.ToString(); //Display results
            } catch
            {
                MessageBox.Show(OPERAND_ERROR);
            }
        }

        private void multBtn_Click(object sender, EventArgs e)
        {
            try
            {
                double op1 = double.Parse(op1Input.Text); //Store operand 1
                double op2 = double.Parse(op2Input.Text); //Store operand 2
                double result = op1 * op2; //Compute calculation
                outputLabel.Text = result.ToString(); //Display results
            } catch
            {
                MessageBox.Show(OPERAND_ERROR);
            }
        }

        private void divBtn_Click(object sender, EventArgs e)
        {
            try
            {
                double op1 = double.Parse(op1Input.Text); //Store operand 1
                double op2 = double.Parse(op2Input.Text); //Store operand 2
                double result = op1 / op2; //Compute calculation
                outputLabel.Text = result.ToString(); //Display results
            }
            catch
            {
                MessageBox.Show(OPERAND_ERROR);
            }
        }
    }
}
