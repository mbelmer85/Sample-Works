﻿namespace Week_3___Calculator
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Operand1 = new System.Windows.Forms.GroupBox();
            this.dig1op1 = new System.Windows.Forms.Button();
            this.dig2op1 = new System.Windows.Forms.Button();
            this.dig3op1 = new System.Windows.Forms.Button();
            this.dig4op1 = new System.Windows.Forms.Button();
            this.dig5op1 = new System.Windows.Forms.Button();
            this.dig6op1 = new System.Windows.Forms.Button();
            this.dig7op1 = new System.Windows.Forms.Button();
            this.dig8op1 = new System.Windows.Forms.Button();
            this.dig9op1 = new System.Windows.Forms.Button();
            this.dig0op1 = new System.Windows.Forms.Button();
            this.backspaceOp1 = new System.Windows.Forms.Button();
            this.op1Input = new System.Windows.Forms.TextBox();
            this.Operand2 = new System.Windows.Forms.GroupBox();
            this.op2Input = new System.Windows.Forms.TextBox();
            this.backspaceOp2 = new System.Windows.Forms.Button();
            this.dig0op2 = new System.Windows.Forms.Button();
            this.dig9op2 = new System.Windows.Forms.Button();
            this.dig8op2 = new System.Windows.Forms.Button();
            this.dig7op2 = new System.Windows.Forms.Button();
            this.dig6op2 = new System.Windows.Forms.Button();
            this.dig5op2 = new System.Windows.Forms.Button();
            this.dig4op2 = new System.Windows.Forms.Button();
            this.dig3op2 = new System.Windows.Forms.Button();
            this.dig2op2 = new System.Windows.Forms.Button();
            this.dig1op2 = new System.Windows.Forms.Button();
            this.addBtn = new System.Windows.Forms.Button();
            this.subBtn = new System.Windows.Forms.Button();
            this.multBtn = new System.Windows.Forms.Button();
            this.divBtn = new System.Windows.Forms.Button();
            this.outputLabel = new System.Windows.Forms.Label();
            this.Operand1.SuspendLayout();
            this.Operand2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Operand1
            // 
            this.Operand1.Controls.Add(this.op1Input);
            this.Operand1.Controls.Add(this.backspaceOp1);
            this.Operand1.Controls.Add(this.dig0op1);
            this.Operand1.Controls.Add(this.dig9op1);
            this.Operand1.Controls.Add(this.dig8op1);
            this.Operand1.Controls.Add(this.dig7op1);
            this.Operand1.Controls.Add(this.dig6op1);
            this.Operand1.Controls.Add(this.dig5op1);
            this.Operand1.Controls.Add(this.dig4op1);
            this.Operand1.Controls.Add(this.dig3op1);
            this.Operand1.Controls.Add(this.dig2op1);
            this.Operand1.Controls.Add(this.dig1op1);
            this.Operand1.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.Operand1.Location = new System.Drawing.Point(37, 46);
            this.Operand1.Name = "Operand1";
            this.Operand1.Size = new System.Drawing.Size(232, 180);
            this.Operand1.TabIndex = 0;
            this.Operand1.TabStop = false;
            this.Operand1.Text = "Operand1";
            // 
            // dig1op1
            // 
            this.dig1op1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig1op1.Location = new System.Drawing.Point(6, 45);
            this.dig1op1.Name = "dig1op1";
            this.dig1op1.Size = new System.Drawing.Size(39, 39);
            this.dig1op1.TabIndex = 0;
            this.dig1op1.Text = "1";
            this.dig1op1.UseVisualStyleBackColor = true;
            this.dig1op1.Click += new System.EventHandler(this.dig1op1_Click);
            // 
            // dig2op1
            // 
            this.dig2op1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig2op1.Location = new System.Drawing.Point(51, 45);
            this.dig2op1.Name = "dig2op1";
            this.dig2op1.Size = new System.Drawing.Size(39, 39);
            this.dig2op1.TabIndex = 1;
            this.dig2op1.Text = "2";
            this.dig2op1.UseVisualStyleBackColor = true;
            this.dig2op1.Click += new System.EventHandler(this.dig2op1_Click);
            // 
            // dig3op1
            // 
            this.dig3op1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig3op1.Location = new System.Drawing.Point(96, 45);
            this.dig3op1.Name = "dig3op1";
            this.dig3op1.Size = new System.Drawing.Size(39, 39);
            this.dig3op1.TabIndex = 2;
            this.dig3op1.Text = "3";
            this.dig3op1.UseVisualStyleBackColor = true;
            this.dig3op1.Click += new System.EventHandler(this.dig3op1_Click);
            // 
            // dig4op1
            // 
            this.dig4op1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig4op1.Location = new System.Drawing.Point(141, 45);
            this.dig4op1.Name = "dig4op1";
            this.dig4op1.Size = new System.Drawing.Size(39, 39);
            this.dig4op1.TabIndex = 3;
            this.dig4op1.Text = "4";
            this.dig4op1.UseVisualStyleBackColor = true;
            this.dig4op1.Click += new System.EventHandler(this.dig4op1_Click);
            // 
            // dig5op1
            // 
            this.dig5op1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig5op1.Location = new System.Drawing.Point(186, 45);
            this.dig5op1.Name = "dig5op1";
            this.dig5op1.Size = new System.Drawing.Size(39, 39);
            this.dig5op1.TabIndex = 4;
            this.dig5op1.Text = "5";
            this.dig5op1.UseVisualStyleBackColor = true;
            this.dig5op1.Click += new System.EventHandler(this.dig5op1_Click);
            // 
            // dig6op1
            // 
            this.dig6op1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig6op1.Location = new System.Drawing.Point(6, 90);
            this.dig6op1.Name = "dig6op1";
            this.dig6op1.Size = new System.Drawing.Size(39, 39);
            this.dig6op1.TabIndex = 5;
            this.dig6op1.Text = "6";
            this.dig6op1.UseVisualStyleBackColor = true;
            this.dig6op1.Click += new System.EventHandler(this.dig6op1_Click);
            // 
            // dig7op1
            // 
            this.dig7op1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig7op1.Location = new System.Drawing.Point(51, 90);
            this.dig7op1.Name = "dig7op1";
            this.dig7op1.Size = new System.Drawing.Size(39, 39);
            this.dig7op1.TabIndex = 6;
            this.dig7op1.Text = "7";
            this.dig7op1.UseVisualStyleBackColor = true;
            this.dig7op1.Click += new System.EventHandler(this.dig7op1_Click);
            // 
            // dig8op1
            // 
            this.dig8op1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig8op1.Location = new System.Drawing.Point(96, 90);
            this.dig8op1.Name = "dig8op1";
            this.dig8op1.Size = new System.Drawing.Size(39, 39);
            this.dig8op1.TabIndex = 7;
            this.dig8op1.Text = "8";
            this.dig8op1.UseVisualStyleBackColor = true;
            this.dig8op1.Click += new System.EventHandler(this.dig8op1_Click);
            // 
            // dig9op1
            // 
            this.dig9op1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig9op1.Location = new System.Drawing.Point(141, 90);
            this.dig9op1.Name = "dig9op1";
            this.dig9op1.Size = new System.Drawing.Size(39, 39);
            this.dig9op1.TabIndex = 8;
            this.dig9op1.Text = "9";
            this.dig9op1.UseVisualStyleBackColor = true;
            this.dig9op1.Click += new System.EventHandler(this.dig9op1_Click);
            // 
            // dig0op1
            // 
            this.dig0op1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig0op1.Location = new System.Drawing.Point(186, 90);
            this.dig0op1.Name = "dig0op1";
            this.dig0op1.Size = new System.Drawing.Size(39, 39);
            this.dig0op1.TabIndex = 9;
            this.dig0op1.Text = "0";
            this.dig0op1.UseVisualStyleBackColor = true;
            this.dig0op1.Click += new System.EventHandler(this.dig0op1_Click);
            // 
            // backspaceOp1
            // 
            this.backspaceOp1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.backspaceOp1.Location = new System.Drawing.Point(51, 135);
            this.backspaceOp1.Name = "backspaceOp1";
            this.backspaceOp1.Size = new System.Drawing.Size(129, 34);
            this.backspaceOp1.TabIndex = 10;
            this.backspaceOp1.Text = "Backspace";
            this.backspaceOp1.UseVisualStyleBackColor = true;
            this.backspaceOp1.Click += new System.EventHandler(this.backspaceOp1_Click);
            // 
            // op1Input
            // 
            this.op1Input.Location = new System.Drawing.Point(6, 19);
            this.op1Input.Name = "op1Input";
            this.op1Input.Size = new System.Drawing.Size(219, 20);
            this.op1Input.TabIndex = 11;
            this.op1Input.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Operand2
            // 
            this.Operand2.Controls.Add(this.op2Input);
            this.Operand2.Controls.Add(this.backspaceOp2);
            this.Operand2.Controls.Add(this.dig0op2);
            this.Operand2.Controls.Add(this.dig9op2);
            this.Operand2.Controls.Add(this.dig8op2);
            this.Operand2.Controls.Add(this.dig7op2);
            this.Operand2.Controls.Add(this.dig6op2);
            this.Operand2.Controls.Add(this.dig5op2);
            this.Operand2.Controls.Add(this.dig4op2);
            this.Operand2.Controls.Add(this.dig3op2);
            this.Operand2.Controls.Add(this.dig2op2);
            this.Operand2.Controls.Add(this.dig1op2);
            this.Operand2.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.Operand2.Location = new System.Drawing.Point(375, 46);
            this.Operand2.Name = "Operand2";
            this.Operand2.Size = new System.Drawing.Size(232, 180);
            this.Operand2.TabIndex = 12;
            this.Operand2.TabStop = false;
            this.Operand2.Text = "Operand2";
            // 
            // op2Input
            // 
            this.op2Input.Location = new System.Drawing.Point(6, 19);
            this.op2Input.Name = "op2Input";
            this.op2Input.Size = new System.Drawing.Size(219, 20);
            this.op2Input.TabIndex = 11;
            this.op2Input.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // backspaceOp2
            // 
            this.backspaceOp2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.backspaceOp2.Location = new System.Drawing.Point(51, 135);
            this.backspaceOp2.Name = "backspaceOp2";
            this.backspaceOp2.Size = new System.Drawing.Size(129, 34);
            this.backspaceOp2.TabIndex = 10;
            this.backspaceOp2.Text = "Backspace";
            this.backspaceOp2.UseVisualStyleBackColor = true;
            this.backspaceOp2.Click += new System.EventHandler(this.backspaceOp2_Click);
            // 
            // dig0op2
            // 
            this.dig0op2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig0op2.Location = new System.Drawing.Point(186, 90);
            this.dig0op2.Name = "dig0op2";
            this.dig0op2.Size = new System.Drawing.Size(39, 39);
            this.dig0op2.TabIndex = 9;
            this.dig0op2.Text = "0";
            this.dig0op2.UseVisualStyleBackColor = true;
            this.dig0op2.Click += new System.EventHandler(this.dig0op2_Click);
            // 
            // dig9op2
            // 
            this.dig9op2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig9op2.Location = new System.Drawing.Point(141, 90);
            this.dig9op2.Name = "dig9op2";
            this.dig9op2.Size = new System.Drawing.Size(39, 39);
            this.dig9op2.TabIndex = 8;
            this.dig9op2.Text = "9";
            this.dig9op2.UseVisualStyleBackColor = true;
            this.dig9op2.Click += new System.EventHandler(this.dig9op2_Click);
            // 
            // dig8op2
            // 
            this.dig8op2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig8op2.Location = new System.Drawing.Point(96, 90);
            this.dig8op2.Name = "dig8op2";
            this.dig8op2.Size = new System.Drawing.Size(39, 39);
            this.dig8op2.TabIndex = 7;
            this.dig8op2.Text = "8";
            this.dig8op2.UseVisualStyleBackColor = true;
            this.dig8op2.Click += new System.EventHandler(this.dig8op2_Click);
            // 
            // dig7op2
            // 
            this.dig7op2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig7op2.Location = new System.Drawing.Point(51, 90);
            this.dig7op2.Name = "dig7op2";
            this.dig7op2.Size = new System.Drawing.Size(39, 39);
            this.dig7op2.TabIndex = 6;
            this.dig7op2.Text = "7";
            this.dig7op2.UseVisualStyleBackColor = true;
            this.dig7op2.Click += new System.EventHandler(this.dig7op2_Click);
            // 
            // dig6op2
            // 
            this.dig6op2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig6op2.Location = new System.Drawing.Point(6, 90);
            this.dig6op2.Name = "dig6op2";
            this.dig6op2.Size = new System.Drawing.Size(39, 39);
            this.dig6op2.TabIndex = 5;
            this.dig6op2.Text = "6";
            this.dig6op2.UseVisualStyleBackColor = true;
            this.dig6op2.Click += new System.EventHandler(this.dig6op2_Click);
            // 
            // dig5op2
            // 
            this.dig5op2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig5op2.Location = new System.Drawing.Point(186, 45);
            this.dig5op2.Name = "dig5op2";
            this.dig5op2.Size = new System.Drawing.Size(39, 39);
            this.dig5op2.TabIndex = 4;
            this.dig5op2.Text = "5";
            this.dig5op2.UseVisualStyleBackColor = true;
            this.dig5op2.Click += new System.EventHandler(this.dig5op2_Click);
            // 
            // dig4op2
            // 
            this.dig4op2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig4op2.Location = new System.Drawing.Point(141, 45);
            this.dig4op2.Name = "dig4op2";
            this.dig4op2.Size = new System.Drawing.Size(39, 39);
            this.dig4op2.TabIndex = 3;
            this.dig4op2.Text = "4";
            this.dig4op2.UseVisualStyleBackColor = true;
            this.dig4op2.Click += new System.EventHandler(this.dig4op2_Click);
            // 
            // dig3op2
            // 
            this.dig3op2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig3op2.Location = new System.Drawing.Point(96, 45);
            this.dig3op2.Name = "dig3op2";
            this.dig3op2.Size = new System.Drawing.Size(39, 39);
            this.dig3op2.TabIndex = 2;
            this.dig3op2.Text = "3";
            this.dig3op2.UseVisualStyleBackColor = true;
            this.dig3op2.Click += new System.EventHandler(this.dig3op2_Click);
            // 
            // dig2op2
            // 
            this.dig2op2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig2op2.Location = new System.Drawing.Point(51, 45);
            this.dig2op2.Name = "dig2op2";
            this.dig2op2.Size = new System.Drawing.Size(39, 39);
            this.dig2op2.TabIndex = 1;
            this.dig2op2.Text = "2";
            this.dig2op2.UseVisualStyleBackColor = true;
            this.dig2op2.Click += new System.EventHandler(this.dig2op2_Click);
            // 
            // dig1op2
            // 
            this.dig1op2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dig1op2.Location = new System.Drawing.Point(6, 45);
            this.dig1op2.Name = "dig1op2";
            this.dig1op2.Size = new System.Drawing.Size(39, 39);
            this.dig1op2.TabIndex = 0;
            this.dig1op2.Text = "1";
            this.dig1op2.UseVisualStyleBackColor = true;
            this.dig1op2.Click += new System.EventHandler(this.dig1op2_Click);
            // 
            // addBtn
            // 
            this.addBtn.Location = new System.Drawing.Point(298, 46);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(43, 39);
            this.addBtn.TabIndex = 13;
            this.addBtn.Text = "+";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // subBtn
            // 
            this.subBtn.Location = new System.Drawing.Point(298, 91);
            this.subBtn.Name = "subBtn";
            this.subBtn.Size = new System.Drawing.Size(43, 39);
            this.subBtn.TabIndex = 14;
            this.subBtn.Text = "-";
            this.subBtn.UseVisualStyleBackColor = true;
            this.subBtn.Click += new System.EventHandler(this.subBtn_Click);
            // 
            // multBtn
            // 
            this.multBtn.Location = new System.Drawing.Point(298, 136);
            this.multBtn.Name = "multBtn";
            this.multBtn.Size = new System.Drawing.Size(43, 39);
            this.multBtn.TabIndex = 15;
            this.multBtn.Text = "*";
            this.multBtn.UseVisualStyleBackColor = true;
            this.multBtn.Click += new System.EventHandler(this.multBtn_Click);
            // 
            // divBtn
            // 
            this.divBtn.Location = new System.Drawing.Point(298, 181);
            this.divBtn.Name = "divBtn";
            this.divBtn.Size = new System.Drawing.Size(43, 39);
            this.divBtn.TabIndex = 16;
            this.divBtn.Text = "/";
            this.divBtn.UseVisualStyleBackColor = true;
            this.divBtn.Click += new System.EventHandler(this.divBtn_Click);
            // 
            // outputLabel
            // 
            this.outputLabel.BackColor = System.Drawing.Color.Gray;
            this.outputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputLabel.Location = new System.Drawing.Point(178, 238);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(287, 56);
            this.outputLabel.TabIndex = 17;
            this.outputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(662, 327);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.divBtn);
            this.Controls.Add(this.multBtn);
            this.Controls.Add(this.subBtn);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.Operand2);
            this.Controls.Add(this.Operand1);
            this.Name = "Calculator";
            this.Text = "Calculator";
            this.Operand1.ResumeLayout(false);
            this.Operand1.PerformLayout();
            this.Operand2.ResumeLayout(false);
            this.Operand2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox Operand1;
        private System.Windows.Forms.TextBox op1Input;
        private System.Windows.Forms.Button backspaceOp1;
        private System.Windows.Forms.Button dig0op1;
        private System.Windows.Forms.Button dig9op1;
        private System.Windows.Forms.Button dig8op1;
        private System.Windows.Forms.Button dig7op1;
        private System.Windows.Forms.Button dig6op1;
        private System.Windows.Forms.Button dig5op1;
        private System.Windows.Forms.Button dig4op1;
        private System.Windows.Forms.Button dig3op1;
        private System.Windows.Forms.Button dig2op1;
        private System.Windows.Forms.Button dig1op1;
        private System.Windows.Forms.GroupBox Operand2;
        private System.Windows.Forms.TextBox op2Input;
        private System.Windows.Forms.Button backspaceOp2;
        private System.Windows.Forms.Button dig0op2;
        private System.Windows.Forms.Button dig9op2;
        private System.Windows.Forms.Button dig8op2;
        private System.Windows.Forms.Button dig7op2;
        private System.Windows.Forms.Button dig6op2;
        private System.Windows.Forms.Button dig5op2;
        private System.Windows.Forms.Button dig4op2;
        private System.Windows.Forms.Button dig3op2;
        private System.Windows.Forms.Button dig2op2;
        private System.Windows.Forms.Button dig1op2;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button subBtn;
        private System.Windows.Forms.Button multBtn;
        private System.Windows.Forms.Button divBtn;
        private System.Windows.Forms.Label outputLabel;
    }
}

