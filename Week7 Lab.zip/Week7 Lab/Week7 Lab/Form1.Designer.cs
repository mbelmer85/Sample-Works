﻿namespace Week7_Lab
{
    partial class textCopyProg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cpyBtn = new System.Windows.Forms.Button();
            this.fileInputBox = new System.Windows.Forms.TextBox();
            this.resultLabel = new System.Windows.Forms.Label();
            this.lineToFileBtn = new System.Windows.Forms.Button();
            this.fileOutputBox = new System.Windows.Forms.TextBox();
            this.fileCpyBtn = new System.Windows.Forms.Button();
            this.inDialog = new System.Windows.Forms.OpenFileDialog();
            this.outDialog = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // cpyBtn
            // 
            this.cpyBtn.Location = new System.Drawing.Point(13, 13);
            this.cpyBtn.Margin = new System.Windows.Forms.Padding(4);
            this.cpyBtn.Name = "cpyBtn";
            this.cpyBtn.Size = new System.Drawing.Size(163, 55);
            this.cpyBtn.TabIndex = 0;
            this.cpyBtn.Text = "Copy Line To Screen";
            this.cpyBtn.UseVisualStyleBackColor = true;
            this.cpyBtn.Click += new System.EventHandler(this.cpyBtn_Click);
            // 
            // fileInputBox
            // 
            this.fileInputBox.Location = new System.Drawing.Point(184, 13);
            this.fileInputBox.Margin = new System.Windows.Forms.Padding(4);
            this.fileInputBox.Name = "fileInputBox";
            this.fileInputBox.Size = new System.Drawing.Size(148, 22);
            this.fileInputBox.TabIndex = 1;
            // 
            // resultLabel
            // 
            this.resultLabel.BackColor = System.Drawing.Color.Coral;
            this.resultLabel.Location = new System.Drawing.Point(184, 98);
            this.resultLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(148, 55);
            this.resultLabel.TabIndex = 2;
            // 
            // lineToFileBtn
            // 
            this.lineToFileBtn.Location = new System.Drawing.Point(13, 73);
            this.lineToFileBtn.Name = "lineToFileBtn";
            this.lineToFileBtn.Size = new System.Drawing.Size(163, 55);
            this.lineToFileBtn.TabIndex = 3;
            this.lineToFileBtn.Text = "Copy Line To File";
            this.lineToFileBtn.UseVisualStyleBackColor = true;
            this.lineToFileBtn.Click += new System.EventHandler(this.lineToFileBtn_Click);
            // 
            // fileOutputBox
            // 
            this.fileOutputBox.Location = new System.Drawing.Point(184, 73);
            this.fileOutputBox.Name = "fileOutputBox";
            this.fileOutputBox.Size = new System.Drawing.Size(148, 22);
            this.fileOutputBox.TabIndex = 4;
            // 
            // fileCpyBtn
            // 
            this.fileCpyBtn.Location = new System.Drawing.Point(13, 135);
            this.fileCpyBtn.Name = "fileCpyBtn";
            this.fileCpyBtn.Size = new System.Drawing.Size(163, 56);
            this.fileCpyBtn.TabIndex = 5;
            this.fileCpyBtn.Text = "Copy File ALL";
            this.fileCpyBtn.UseVisualStyleBackColor = true;
            this.fileCpyBtn.Click += new System.EventHandler(this.fileCpyBtn_Click);
            // 
            // inDialog
            // 
            this.inDialog.FileName = "openFileDialog1";
            // 
            // textCopyProg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(361, 212);
            this.Controls.Add(this.fileCpyBtn);
            this.Controls.Add(this.fileOutputBox);
            this.Controls.Add(this.lineToFileBtn);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.fileInputBox);
            this.Controls.Add(this.cpyBtn);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "textCopyProg";
            this.Text = "Text Copy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cpyBtn;
        private System.Windows.Forms.TextBox fileInputBox;
        private System.Windows.Forms.Label resultLabel;
        private System.Windows.Forms.Button lineToFileBtn;
        private System.Windows.Forms.TextBox fileOutputBox;
        private System.Windows.Forms.Button fileCpyBtn;
        private System.Windows.Forms.OpenFileDialog inDialog;
        private System.Windows.Forms.SaveFileDialog outDialog;
    }
}

