﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;  // needed for access to StreamReader type

namespace Week7_Lab
{
    public partial class textCopyProg : Form
    {
        public textCopyProg()
        {
            InitializeComponent();
        }

        private void cpyBtn_Click(object sender, EventArgs e)
        {
            StreamReader fileInput;    // variable to store a StreamReader object
            try
            {
                fileInput = File.OpenText(fileInputBox.Text);  // create a StreamReader object associated with file indicated, which is now open

                string line = fileInput.ReadLine(); // reads first line from file and stores it
                resultLabel.Text = line;

                fileInput.Close(); // done with file, closing it
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void lineToFileBtn_Click(object sender, EventArgs e)
        {
            try
            {
                StreamReader fileInput = File.OpenText(fileInputBox.Text); // open input file
                StreamWriter fileOutput;
                fileOutput = File.CreateText(fileOutputBox.Text);  // created a new output file

                string line;
                line = fileInput.ReadLine();

                fileOutput.WriteLine(line);

                fileInput.Close();
                fileOutput.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void fileCpyBtn_Click(object sender, EventArgs e)
        {
            try
            {
                StreamReader fileInput;
                StreamWriter fileOutput;

                //fileInput = File.OpenText(fileInputBox.Text);
                inDialog.ShowDialog(); // causes inDialog object to appear
                fileInput = File.OpenText(inDialog.FileName);

                //fileOutput = File.CreateText(fileOutputBox.Text);
                outDialog.ShowDialog(); // causes outDialog object to appear
                fileOutput = File.CreateText(outDialog.FileName);

                string line;

                while (fileInput.EndOfStream != true)
                {  // while unread lines reamin in file, continue to read and write lines to file
                    line = fileInput.ReadLine();
                    fileOutput.WriteLine(line);
                }

                fileInput.Close();
                fileOutput.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
