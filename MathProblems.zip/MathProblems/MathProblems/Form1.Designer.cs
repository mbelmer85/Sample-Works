﻿namespace MathProblems
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.problemBox = new System.Windows.Forms.ListBox();
            this.nextBtn = new System.Windows.Forms.Button();
            this.checkBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.numInput = new System.Windows.Forms.TextBox();
            this.inputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // problemBox
            // 
            this.problemBox.FormattingEnabled = true;
            this.problemBox.ItemHeight = 16;
            this.problemBox.Location = new System.Drawing.Point(245, 13);
            this.problemBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.problemBox.Name = "problemBox";
            this.problemBox.Size = new System.Drawing.Size(260, 132);
            this.problemBox.TabIndex = 0;
            // 
            // nextBtn
            // 
            this.nextBtn.BackColor = System.Drawing.Color.MediumTurquoise;
            this.nextBtn.Location = new System.Drawing.Point(13, 13);
            this.nextBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nextBtn.Name = "nextBtn";
            this.nextBtn.Size = new System.Drawing.Size(208, 62);
            this.nextBtn.TabIndex = 1;
            this.nextBtn.Text = "NEXT";
            this.nextBtn.UseVisualStyleBackColor = false;
            this.nextBtn.Click += new System.EventHandler(this.nextBtn_Click);
            // 
            // checkBtn
            // 
            this.checkBtn.BackColor = System.Drawing.Color.MediumTurquoise;
            this.checkBtn.Enabled = false;
            this.checkBtn.Location = new System.Drawing.Point(13, 169);
            this.checkBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkBtn.Name = "checkBtn";
            this.checkBtn.Size = new System.Drawing.Size(208, 62);
            this.checkBtn.TabIndex = 2;
            this.checkBtn.Text = "CHECK ANSWER";
            this.checkBtn.UseVisualStyleBackColor = false;
            this.checkBtn.Click += new System.EventHandler(this.checkBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.BackColor = System.Drawing.Color.MediumTurquoise;
            this.exitBtn.Location = new System.Drawing.Point(395, 253);
            this.exitBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(110, 62);
            this.exitBtn.TabIndex = 3;
            this.exitBtn.Text = "EXIT";
            this.exitBtn.UseVisualStyleBackColor = false;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // numInput
            // 
            this.numInput.Location = new System.Drawing.Point(245, 209);
            this.numInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.numInput.Name = "numInput";
            this.numInput.Size = new System.Drawing.Size(260, 22);
            this.numInput.TabIndex = 4;
            // 
            // inputLabel
            // 
            this.inputLabel.AutoSize = true;
            this.inputLabel.Location = new System.Drawing.Point(242, 166);
            this.inputLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.inputLabel.Name = "inputLabel";
            this.inputLabel.Size = new System.Drawing.Size(114, 16);
            this.inputLabel.TabIndex = 5;
            this.inputLabel.Text = "Your ANSWER:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(534, 344);
            this.Controls.Add(this.inputLabel);
            this.Controls.Add(this.numInput);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.checkBtn);
            this.Controls.Add(this.nextBtn);
            this.Controls.Add(this.problemBox);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox problemBox;
        private System.Windows.Forms.Button nextBtn;
        private System.Windows.Forms.Button checkBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.TextBox numInput;
        private System.Windows.Forms.Label inputLabel;
    }
}

