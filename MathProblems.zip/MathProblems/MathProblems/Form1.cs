﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MathProblems
{
    public partial class Form1 : Form

    {
        public StreamWriter problemsFile;
        public StreamReader fileRead;
        public Random numGen;
        public int eqNum1;
        public int eqNum2;

        public Form1()
        {
            InitializeComponent();
        } // End Form1()

        private void Form1_Load(object sender, EventArgs e)
        {
            numGen = new Random();
            problemsFile = File.CreateText("Problems.txt");

            for (int i = 0; i <= 9; i++)   // Create txt file with 10 random numbers 0 to 100
            {
                int num = numGen.Next(0, 101);
                problemsFile.WriteLine(num);
            } // End for

            problemsFile.Close();
            fileRead = File.OpenText("Problems.txt");    // Open Problems.txt for future program reads
        } // End Form1_Load

        private void nextBtn_Click(object sender, EventArgs e)
        {
            if(checkBtn.Enabled == false)    // Toggle Check and Next Enable values so a problem must be answered before moving on
            {
                checkBtn.Enabled = true;
                nextBtn.Enabled = false;
            } // End if

            problemBox.Items.Clear();
            string equation;

            if (!fileRead.EndOfStream)   // Check for end of file
            {
                eqNum1 = int.Parse(fileRead.ReadLine());
                eqNum2 = int.Parse(fileRead.ReadLine());
                equation = eqNum1.ToString() + " + " + eqNum2.ToString() + " =";
                problemBox.Items.Add(equation);
            } // End if
            else
            {
                MessageBox.Show("No more problems to solve!");
                checkBtn.Enabled = false;
                nextBtn.Enabled = false;
            } // End else
        } // End nextBtn_click

        private void checkBtn_Click(object sender, EventArgs e)
        {
            int sum = eqNum1 + eqNum2;
            try
            {
                int answer = int.Parse(numInput.Text);
                if (sum == answer)                             // Check for correct answer
                {
                    problemBox.Items.Add("Correct!");
                    numInput.Text = "";
                    checkBtn.Enabled = false;
                    nextBtn.Enabled = true;
                } // End if
                else
                {
                    problemBox.Items.Add("Incorrect, try again...");
                    numInput.Text = "";
                } // End else
            } // End try
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                numInput.Text = "";
            } // End catch
        } // End checkBtn_Click

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();                         // Close application
        } // End exitBtn_Click
    } // End Class Form1
} // End Namespace MathProblems
